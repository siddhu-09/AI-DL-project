"""
Curated sample images dataset for the Image Caption Generator.
Provides instant testing examples with Flickr-style ground-truth reference captions
for BLEU score benchmarking.
"""

from typing import List, Dict, Any

SAMPLE_IMAGES: List[Dict[str, Any]] = [
    {
        "id": "sample-1",
        "title": "Dog Playing in Park",
        "category": "Animals & Nature",
        "image_url": "https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=800&q=80",
        "thumbnail": "https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=300&q=80",
        "expected_caption": "a brown dog is running through a grassy green field",
        "reference_captions": [
            "a brown dog is running through a grassy green field",
            "a dog runs outdoors in a green park with trees",
            "a happy dog sprinting across the grass with ears back",
            "a hound dog galloping across an open meadow",
            "a dog playing joyfully on the lawn in daylight"
        ]
    },
    {
        "id": "sample-2",
        "title": "Ocean Surfer",
        "category": "Sports & Action",
        "image_url": "https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=800&q=80",
        "thumbnail": "https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=300&q=80",
        "expected_caption": "a person is riding a surfboard on a large ocean wave",
        "reference_captions": [
            "a person is riding a surfboard on a large ocean wave",
            "a surfer riding inside a curling crest of sea water",
            "an athlete balancing on a surfboard in blue ocean waters",
            "a man surfs along the crest of a massive cresting wave",
            "surfer cutting through blue water under the sunshine"
        ]
    },
    {
        "id": "sample-3",
        "title": "Cat on Sofa",
        "category": "Pets & Domestic",
        "image_url": "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=800&q=80",
        "thumbnail": "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=300&q=80",
        "expected_caption": "a cute fluffy cat is sitting on a white sofa next to a window",
        "reference_captions": [
            "a cute fluffy cat is sitting on a white sofa next to a window",
            "a domestic cat resting comfortably indoors on a couch",
            "a green-eyed feline lounging on upholstered furniture",
            "a cozy cat relaxing on the soft cushion of a living room sofa",
            "close up of a beautiful cat staring intently at the camera"
        ]
    },
    {
        "id": "sample-4",
        "title": "Cyclist in City",
        "category": "Urban & Transit",
        "image_url": "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=800&q=80",
        "thumbnail": "https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=300&q=80",
        "expected_caption": "a cyclist is riding a bicycle down a busy city street",
        "reference_captions": [
            "a cyclist is riding a bicycle down a busy city street",
            "a person pedaling a bicycle on the asphalt road in town",
            "a commuter riding a bike past vehicles and buildings",
            "cyclist with helmet cruising down an urban street in daylight",
            "a bike rider navigating through traffic in the city center"
        ]
    },
    {
        "id": "sample-5",
        "title": "Commercial Airplane in Sky",
        "category": "Aviation",
        "image_url": "https://images.unsplash.com/photo-1508873696983-2df5293cb32b?auto=format&fit=crop&w=800&q=80",
        "thumbnail": "https://images.unsplash.com/photo-1508873696983-2df5293cb32b?auto=format&fit=crop&w=300&q=80",
        "expected_caption": "a large commercial airplane is flying above fluffy white clouds",
        "reference_captions": [
            "a large commercial airplane is flying above fluffy white clouds",
            "a passenger jet cruising high in the sky over white clouds",
            "an aircraft flying through blue sky surrounded by clouds",
            "commercial airplane ascending through the atmosphere",
            "a twin-engine jetliner high above cloud formations"
        ]
    },
    {
        "id": "sample-6",
        "title": "Fresh Baked Pizza",
        "category": "Food & Dining",
        "image_url": "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80",
        "thumbnail": "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=300&q=80",
        "expected_caption": "a delicious pepperoni pizza on a wooden table in a restaurant",
        "reference_captions": [
            "a delicious pepperoni pizza on a wooden table in a restaurant",
            "a whole baked pizza with melted cheese and toppings on a board",
            "freshly cooked Italian pizza ready to be served on a table",
            "a hot artisan pizza with crust and tomato sauce sliced",
            "savory pizza pie with cheese and herbs served on wood"
        ]
    }
]

def get_all_samples() -> List[Dict[str, Any]]:
    return SAMPLE_IMAGES

def get_sample_by_id(sample_id: str) -> Dict[str, Any]:
    for sample in SAMPLE_IMAGES:
        if sample["id"] == sample_id:
            return sample
    return SAMPLE_IMAGES[0]
