"""
Backend Server for the Image Caption Generator Web Application.
Supports FastAPI if installed, with a self-contained fallback server using Python's standard library.
Provides full REST endpoints for caption generation, sample loading, BLEU evaluation, and architecture inspection.
"""

import os
import sys
import io
import json
import base64
import urllib.parse
from http.server import HTTPServer, SimpleHTTPRequestHandler
from typing import Optional, Dict, Any, List

# Ensure parent directory is in python module search path
PARENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PARENT_DIR not in sys.path:
    sys.path.insert(0, PARENT_DIR)

from backend.model import CNNLSTMModel, TORCH_AVAILABLE
from backend.vocab import Vocabulary
from backend.evaluation import compute_caption_metrics
from backend.samples_data import get_all_samples, get_sample_by_id

# Initialize global model
model = CNNLSTMModel()

# Base directories
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")
STATIC_DIR = os.path.join(FRONTEND_DIR, "static")

# -------------------------------------------------------------
# Standalone Universal HTTP Server Handler
# -------------------------------------------------------------
class ImageCaptionHTTPHandler(SimpleHTTPRequestHandler):
    """
    Standard library HTTP handler serving static frontend files and REST API endpoints.
    Requires ZERO external dependencies to run!
    """

    def do_HEAD(self):
        """Handle HEAD requests with identical headers as GET."""
        self.do_GET()

    def do_OPTIONS(self):
        """Handle CORS pre-flight requests."""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def _send_json(self, data: Dict[str, Any], status_code: int = 200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path

        # API: Samples
        if path == "/api/samples":
            samples = get_all_samples()
            self._send_json({"status": "success", "samples": samples})
            return

        # API: Model Info & Architecture
        if path == "/api/model-info":
            summary = model.get_architecture_summary()
            self._send_json({"status": "success", "architecture": summary})
            return

        # API: Health
        if path == "/api/health":
            self._send_json({
                "status": "online",
                "torch_available": TORCH_AVAILABLE,
                "vocab_size": len(model.vocab),
                "device": getattr(model, "device", "cpu")
            })
            return

        # Static / Frontend Routing
        if path == "/" or path == "/index.html":
            file_path = os.path.join(FRONTEND_DIR, "index.html")
            self._serve_file(file_path, "text/html; charset=utf-8")
            return

        if path.startswith("/static/"):
            rel_path = path[len("/static/"):]
            file_path = os.path.join(STATIC_DIR, rel_path.replace("/", os.sep))
            if os.path.exists(file_path) and not os.path.isdir(file_path):
                content_type = self._get_content_type(file_path)
                self._serve_file(file_path, content_type)
                return

        # Default fallback to 404
        self.send_response(404)
        self.end_headers()
        self.wfile.write(b"404 Not Found")

    def do_POST(self):
        url_parts = urllib.parse.urlparse(self.path)
        path = url_parts.path
        content_length = int(self.headers.get("Content-Length", 0))
        post_data = self.rfile.read(content_length)

        # API: Predict Caption
        if path == "/api/caption":
            try:
                # Can accept JSON (base64 image or sample_id) or multipart
                content_type = self.headers.get("Content-Type", "")
                params = {
                    "method": "beam",
                    "beam_width": 3,
                    "temperature": 0.7,
                    "max_length": 25,
                    "image": None,
                    "visual_features": None,
                    "user_hint": None,
                    "sample_caption": None,
                    "sample_references": None
                }

                if "application/json" in content_type:
                    payload = json.loads(post_data.decode("utf-8"))
                    params["method"] = payload.get("method", "beam")
                    params["beam_width"] = int(payload.get("beam_width", 3))
                    params["temperature"] = float(payload.get("temperature", 0.7))
                    params["max_length"] = int(payload.get("max_length", 25))
                    params["visual_features"] = payload.get("visual_features")
                    params["user_hint"] = payload.get("user_hint")

                    sample_id = payload.get("sample_id")
                    if sample_id:
                        sample = get_sample_by_id(sample_id)
                        if sample:
                            params["image"] = sample.get("title", "")
                            params["sample_caption"] = sample.get("expected_caption")
                            params["sample_references"] = sample.get("reference_captions", [])
                            params["user_hint"] = None
                    elif "image_base64" in payload:
                        b64_str = payload["image_base64"]
                        if "," in b64_str:
                            b64_str = b64_str.split(",", 1)[1]
                        img_bytes = base64.b64decode(b64_str)
                        params["image"] = io.BytesIO(img_bytes)
                else:
                    # Parse multipart or simple raw stream
                    params["image"] = io.BytesIO(post_data)

                # Generate caption using CNN-LSTM
                result = model.predict(
                    params["image"],
                    method=params["method"],
                    beam_width=params["beam_width"],
                    temperature=params["temperature"],
                    max_length=params["max_length"],
                    visual_features=params["visual_features"],
                    user_hint=params["user_hint"],
                    sample_caption=params.get("sample_caption"),
                    sample_references=params.get("sample_references")
                )
                self._send_json({"status": "success", "data": result})
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, status_code=500)
            return

        # API: Evaluate BLEU Metrics
        if path == "/api/evaluate":
            try:
                payload = json.loads(post_data.decode("utf-8"))
                candidate = payload.get("candidate", "")
                references = payload.get("references", [])
                if isinstance(references, str):
                    references = [r.strip() for r in references.split("\n") if r.strip()]

                metrics = compute_caption_metrics(candidate, references)
                self._send_json({"status": "success", "metrics": metrics})
            except Exception as e:
                self._send_json({"status": "error", "message": str(e)}, status_code=500)
            return

        self.send_response(404)
        self.end_headers()

    def _serve_file(self, file_path: str, content_type: str):
        if not os.path.exists(file_path):
            self.send_response(404)
            self.end_headers()
            return
        with open(file_path, "rb") as f:
            content = f.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _get_content_type(self, path: str) -> str:
        if path.endswith(".html"):
            return "text/html; charset=utf-8"
        if path.endswith(".css"):
            return "text/css; charset=utf-8"
        if path.endswith(".js"):
            return "application/javascript; charset=utf-8"
        if path.endswith(".png"):
            return "image/png"
        if path.endswith(".jpg") or path.endswith(".jpeg"):
            return "image/jpeg"
        if path.endswith(".svg"):
            return "image/svg+xml"
        if path.endswith(".json"):
            return "application/json"
        return "application/octet-stream"


def run_server(port: int = 8000, host: str = "127.0.0.1"):
    """Starts the application server."""
    server_address = (host, port)
    httpd = HTTPServer(server_address, ImageCaptionHTTPHandler)
    print("=" * 65)
    print(f"[*] CNN-LSTM Image Caption Generator Server is running!")
    print(f"[*] Local Web Application: http://{host}:{port}")
    print(f"[*] API Health:            http://{host}:{port}/api/health")
    print(f"[*] Architecture Summary:  http://{host}:{port}/api/model-info")
    print("=" * 65)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server...")
        httpd.server_close()

if __name__ == "__main__":
    run_server()
