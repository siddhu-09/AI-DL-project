"""
Vocabulary class for CNN-LSTM Image Caption Generator.
Handles tokenization, numericalization, special tokens (<pad>, <start>, <end>, <unk>),
and serialization of the dictionary.
"""

import json
import re
from collections import Counter
from typing import List, Dict, Union

class Vocabulary:
    PAD_TOKEN = "<pad>"
    START_TOKEN = "<start>"
    END_TOKEN = "<end>"
    UNK_TOKEN = "<unk>"

    def __init__(self, freq_threshold: int = 2):
        self.freq_threshold = freq_threshold
        self.word2idx: Dict[str, int] = {}
        self.idx2word: Dict[int, str] = {}
        self.idx = 0
        
        # Initialize special tokens
        self.add_word(self.PAD_TOKEN)    # 0
        self.add_word(self.START_TOKEN)  # 1
        self.add_word(self.END_TOKEN)    # 2
        self.add_word(self.UNK_TOKEN)    # 3

    def __len__(self) -> int:
        return len(self.word2idx)

    def add_word(self, word: str) -> int:
        """Add a single word to the vocabulary if not already present."""
        word = word.lower()
        if word not in self.word2idx:
            self.word2idx[word] = self.idx
            self.idx2word[self.idx] = word
            self.idx += 1
        return self.word2idx[word]

    @staticmethod
    def clean_text(text: str) -> List[str]:
        """Convert string to cleaned tokens: lowercase, punctuation removed."""
        text = text.lower().strip()
        tokens = re.findall(r"\b[a-zA-Z0-9'-]+\b", text)
        return tokens

    def build_vocab(self, sentence_list: List[str]):
        """Build vocabulary from a list of sentence strings."""
        frequencies = Counter()
        for sentence in sentence_list:
            tokens = self.clean_text(sentence)
            frequencies.update(tokens)

        for word, count in frequencies.items():
            if count >= self.freq_threshold:
                self.add_word(word)

    def numericalize(self, text: Union[str, List[str]], add_boundary: bool = True) -> List[int]:
        """Convert a sentence into a sequence of token IDs."""
        tokens = self.clean_text(text) if isinstance(text, str) else [t.lower() for t in text]
        result = []
        if add_boundary:
            result.append(self.word2idx[self.START_TOKEN])
        for token in tokens:
            result.append(self.word2idx.get(token, self.word2idx[self.UNK_TOKEN]))
        if add_boundary:
            result.append(self.word2idx[self.END_TOKEN])
        return result

    def decode(self, indices: List[int], remove_special: bool = True) -> str:
        """Convert list of token IDs back into a human-readable sentence."""
        words = []
        for idx in indices:
            word = self.idx2word.get(idx, self.UNK_TOKEN)
            if remove_special and word in [self.PAD_TOKEN, self.START_TOKEN, self.END_TOKEN]:
                continue
            words.append(word)
        return " ".join(words)

    def save(self, filepath: str):
        """Save vocabulary to JSON."""
        data = {
            "freq_threshold": self.freq_threshold,
            "word2idx": self.word2idx,
            "idx2word": {str(k): v for k, v in self.idx2word.items()},
            "idx": self.idx
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, filepath: str) -> "Vocabulary":
        """Load vocabulary from JSON."""
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        vocab = cls(freq_threshold=data.get("freq_threshold", 2))
        vocab.word2idx = data["word2idx"]
        vocab.idx2word = {int(k): v for k, v in data["idx2word"].items()}
        vocab.idx = data["idx"]
        return vocab


def create_default_vocabulary() -> Vocabulary:
    """Creates a comprehensive default vocabulary for standard Flickr/COCO caption domains."""
    vocab = Vocabulary(freq_threshold=1)
    
    # Common vision words (people, animals, objects, actions, environments, colors)
    words = [
        # Animals
        "dog", "dogs", "cat", "cats", "puppy", "kitten", "bird", "birds", "horse", "horses",
        "cow", "cows", "sheep", "elephant", "bear", "zebra", "giraffe", "duck", "goose",
        "animal", "pet", "pets",
        # People & Characters
        "man", "men", "woman", "women", "boy", "boys", "girl", "girls", "child", "children",
        "baby", "person", "people", "player", "athlete", "crowd", "toddler", "friend", "friends",
        "worker", "student", "portrait", "selfie", "face", "figure", "hero", "superhero", "batman",
        "knight", "silhouette", "shadow", "shadowy",
        # Actions
        "running", "jumping", "sitting", "standing", "walking", "playing", "riding", "looking",
        "holding", "eating", "wearing", "carrying", "flying", "swimming", "sleeping", "driving",
        "cooking", "reading", "smiling", "catching", "throwing", "climbing", "posing", "racing",
        "working", "typing", "studying", "relaxing", "talking", "resting", "lounging", "using",
        # Objects & Tech
        "ball", "frisbee", "bicycle", "bike", "car", "cars", "bus", "train", "airplane", "boat",
        "motorcycle", "skateboard", "surfboard", "skis", "snowboard", "bench", "chair", "table",
        "couch", "sofa", "bed", "hat", "shirt", "jacket", "dress", "glasses", "sunglasses",
        "backpack", "phone", "camera", "laptop", "computer", "screen", "keyboard", "mouse", "desk",
        "book", "cup", "bottle", "plate", "bowl", "food", "pizza", "cake", "sandwich", "guitar",
        "racket", "tennis", "soccer", "baseball", "pen", "paper", "clock", "flower", "flowers",
        "plant", "plants", "tree", "trees", "leaves", "cape", "costume",
        # Environments & Places
        "park", "beach", "field", "grass", "grassy", "water", "river", "lake", "ocean", "sea",
        "street", "road", "sidewalk", "room", "kitchen", "living", "bedroom", "office", "garden",
        "forest", "mountain", "snow", "snowy", "hill", "dirt", "track", "stage", "bridge",
        "building", "buildings", "indoor", "indoors", "interior", "outdoor", "outdoors", "sky",
        "clouds", "cloudy", "sunny", "sunlight", "wall", "floor", "window", "smoke", "smoky",
        "mist", "haze", "fire", "fiery", "background",
        # Colors & Attributes
        "red", "blue", "green", "yellow", "white", "black", "brown", "orange", "pink", "purple",
        "gray", "grey", "golden", "dark", "light", "bright", "small", "little", "big", "large",
        "young", "old", "cute", "happy", "wooden", "metal", "stone", "modern", "scenic", "delicious",
        "fresh", "beautiful", "soft", "glowing", "dramatic", "atmospheric", "mysterious",
        # Prepositions, Determiners & Conjunctions
        "a", "an", "the", "in", "on", "at", "by", "with", "from", "into", "over", "under",
        "through", "above", "behind", "next", "to", "front", "of", "and", "or", "while", "as",
        "is", "are", "was", "were", "has", "have", "its", "their", "two", "three", "four", "several"
    ]
    for w in words:
        vocab.add_word(w)
    return vocab
