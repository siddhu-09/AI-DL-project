"""
Evaluation metrics module for Image Captioning.
Calculates BLEU-1, BLEU-2, BLEU-3, BLEU-4 scores,
supporting both NLTK and a self-contained pure-Python fallback.
"""

import math
import re
from collections import Counter
from typing import List, Dict, Union

def _tokenize(text: str) -> List[str]:
    """Helper to clean and tokenize a sentence."""
    text = text.lower().strip()
    return re.findall(r"\b[a-zA-Z0-9'-]+\b", text)

def _get_ngrams(tokens: List[str], n: int) -> Counter:
    """Extract n-grams count from a list of tokens."""
    return Counter(tuple(tokens[i:i+n]) for i in range(len(tokens) - n + 1))

def pure_python_bleu(
    candidate: List[str],
    references: List[List[str]],
    weights: tuple = (0.25, 0.25, 0.25, 0.25)
) -> float:
    """
    Pure Python calculation of BLEU score according to Papineni et al. (2002).
    Includes modified n-gram precision and brevity penalty.
    """
    c_len = len(candidate)
    if c_len == 0:
        return 0.0

    # Calculate closest reference length for brevity penalty
    ref_lengths = [len(r) for r in references]
    closest_ref_len = min(ref_lengths, key=lambda r: (abs(r - c_len), r))

    # Brevity penalty
    if c_len > closest_ref_len:
        bp = 1.0
    else:
        bp = math.exp(1.0 - (closest_ref_len / c_len))

    # Calculate modified precision for each n
    log_sum = 0.0
    for n, weight in enumerate(weights, start=1):
        if weight == 0:
            continue
        cand_ngrams = _get_ngrams(candidate, n)
        if not cand_ngrams:
            # If no n-grams can be formed, smooth with small epsilon
            p_n = 1e-9
        else:
            # Max count across references for each n-gram
            max_ref_counts = Counter()
            for ref in references:
                ref_ngrams = _get_ngrams(ref, n)
                for ng in cand_ngrams:
                    max_ref_counts[ng] = max(max_ref_counts[ng], ref_ngrams[ng])

            clipped_matches = sum(min(count, max_ref_counts[ng]) for ng, count in cand_ngrams.items())
            total_cand_ngrams = sum(cand_ngrams.values())
            p_n = (clipped_matches / total_cand_ngrams) if total_cand_ngrams > 0 else 1e-9

        if p_n == 0:
            p_n = 1e-9
        log_sum += weight * math.log(p_n)

    bleu = bp * math.exp(log_sum)
    return round(max(0.0, min(1.0, bleu)), 4)


def compute_caption_metrics(
    candidate_caption: str,
    reference_captions: Union[str, List[str]]
) -> Dict[str, float]:
    """
    Compute BLEU-1, BLEU-2, BLEU-3, BLEU-4 and lexical overlap metrics.
    Works whether reference is single string or list of references (e.g., Flickr 5-ref format).
    """
    cand_tokens = _tokenize(candidate_caption)
    
    if isinstance(reference_captions, str):
        refs = [_tokenize(reference_captions)]
    else:
        refs = [_tokenize(r) for r in reference_captions if r.strip()]

    if not refs or not cand_tokens:
        return {
            "bleu1": 0.0,
            "bleu2": 0.0,
            "bleu3": 0.0,
            "bleu4": 0.0,
            "rouge_l": 0.0,
            "brevity_penalty": 0.0
        }

    # Try importing NLTK if available, otherwise use pure python implementation
    try:
        from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
        smooth = SmoothingFunction().method1
        b1 = sentence_bleu(refs, cand_tokens, weights=(1.0, 0, 0, 0), smoothing_function=smooth)
        b2 = sentence_bleu(refs, cand_tokens, weights=(0.5, 0.5, 0, 0), smoothing_function=smooth)
        b3 = sentence_bleu(refs, cand_tokens, weights=(0.33, 0.33, 0.33, 0), smoothing_function=smooth)
        b4 = sentence_bleu(refs, cand_tokens, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=smooth)
    except ImportError:
        b1 = pure_python_bleu(cand_tokens, refs, weights=(1.0, 0, 0, 0))
        b2 = pure_python_bleu(cand_tokens, refs, weights=(0.5, 0.5, 0, 0))
        b3 = pure_python_bleu(cand_tokens, refs, weights=(0.333, 0.333, 0.334, 0))
        b4 = pure_python_bleu(cand_tokens, refs, weights=(0.25, 0.25, 0.25, 0.25))

    # Simple ROUGE-L (Longest Common Subsequence) score
    def lcs(x: List[str], y: List[str]) -> int:
        dp = [[0] * (len(y) + 1) for _ in range(len(x) + 1)]
        for i in range(len(x)):
            for j in range(len(y)):
                if x[i] == y[j]:
                    dp[i + 1][j + 1] = dp[i][j] + 1
                else:
                    dp[i + 1][j + 1] = max(dp[i + 1][j], dp[i][j + 1])
        return dp[-1][-1]

    best_lcs = max(lcs(cand_tokens, ref) for ref in refs)
    avg_ref_len = sum(len(r) for r in refs) / len(refs)
    rec = best_lcs / avg_ref_len if avg_ref_len > 0 else 0
    prec = best_lcs / len(cand_tokens) if len(cand_tokens) > 0 else 0
    rouge_l = (2 * prec * rec / (prec + rec)) if (prec + rec) > 0 else 0.0

    return {
        "bleu1": round(float(b1) * 100, 2),
        "bleu2": round(float(b2) * 100, 2),
        "bleu3": round(float(b3) * 100, 2),
        "bleu4": round(float(b4) * 100, 2),
        "rouge_l": round(float(rouge_l) * 100, 2)
    }
