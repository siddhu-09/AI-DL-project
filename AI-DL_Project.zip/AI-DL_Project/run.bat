@echo off
title CNN-LSTM Image Caption Generator
echo ======================================================================
echo    Starting CNN-LSTM Image Caption Generator Web Application
echo ======================================================================
echo.

IF EXIST ".venv\Scripts\python.exe" (
    echo [i] Using project virtual environment: .venv\Scripts\python.exe
    ".venv\Scripts\python.exe" start.py
) ELSE (
    echo [i] Using system python
    python start.py
)

pause
