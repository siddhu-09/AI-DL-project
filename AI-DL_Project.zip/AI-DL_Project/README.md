# NeuroCaption: Image Caption Generator using CNN-LSTM

An end-to-end Deep Learning web application that automatically translates visual content into descriptive, natural language captions using an **Encoder-Decoder CNN-LSTM** neural architecture.

---

## 🌟 Key Features

1. **Dual Deep Learning Pipeline**:
   - **CNN Encoder (ResNet-50)**: Extracts rich 2048-dimensional spatial visual feature vectors from input images.
   - **LSTM Decoder**: Recurrent neural network with gated memory cells autoregressively predicting sequential tokens with word embeddings.
   - **Bahdanau Attention Mechanism**: Dynamically focuses on salient spatial image regions during sequential token generation ("Show, Attend and Tell").
2. **Advanced Decoding Strategies**:
   - **Beam Search Decoding**: Maintains top-$K$ candidate hypotheses with length normalization to maximize cumulative sentence probability.
   - **Greedy Search**: Fast argmax decoding at each recurrent step.
   - **Temperature Control**: Adjustable softmax temperature ($\tau$) to balance determinism vs. diversity.
3. **Interactive Modern Web Application**:
   - **Image Studio**: Drag & drop upload, local file browsing, URL loading, and **live webcam snapshot capture**.
   - **Quick-Test Gallery**: Curated test samples (dog in park, surfer, cyclist, aircraft, cat on sofa, pizza) for 1-click evaluation.
   - **Word-Level Probability Breakdown**: Visual token chips showing softmax conditional probabilities $P(w_t \mid w_{<t}, I)$.
   - **Text-to-Speech (TTS)**: Built-in audio synthesis to read generated captions aloud.
   - **Quantitative BLEU Benchmarking**: Real-time computation of **BLEU-1, BLEU-2, BLEU-3, BLEU-4**, and **ROUGE-L** against reference human ground truths.
   - **Interactive Architecture Visualizer**: Live inspection of tensor dimensions, layer parameters, and neural configurations.

---

## 🏗️ Architecture Overview

```
                      [ Input Image (224 x 224 x 3) ]
                                     │
                                     ▼
                      [ CNN Encoder (ResNet-50) ]
                        - 50 Residual Conv layers
                        - Pre-trained on ImageNet
                                     │
                                     ▼
                        [ 2048-dim Feature Vector ]
                                     │
                                     ▼
                [ Linear Projection + BatchNorm + Dropout ]
                                     │
                                     ▼
                          [ 512-dim Image Embedding ]
                                     │
         ┌───────────────────────────┴───────────────────────────┐
         ▼                                                       ▼
[ Initial Hidden State (h_0, c_0) ]             [ Attention Weighting (alpha_t) ]
         │                                                       │
         └───────────────────────────┬───────────────────────────┘
                                     │
                                     ▼
                [ LSTM Decoder (Hidden State: 512-dim) ]
                     - Word Embedding Layer (512-dim)
                     - Input, Forget, and Output Gates
                     - Softmax over Vocabulary (|V| tokens)
                                     │
                                     ▼
                      [ Beam Search / Greedy Pruning ]
                                     │
                                     ▼
       [ "a brown dog is running through a grassy green field" ]
```

---

## 📂 Project Directory Structure

```
AI-DL_Project/
├── backend/
│   ├── __init__.py
│   ├── app.py               # REST API & static server (Zero-dependency standard lib + FastAPI ready)
│   ├── model.py             # PyTorch CNN-LSTM Architecture, ResNet50, Bahdanau Attention, Beam Search
│   ├── vocab.py             # Vocabulary builder, tokenization, <pad>, <start>, <end>, <unk>
│   ├── evaluation.py        # BLEU-1 to BLEU-4 and ROUGE-L metrics computation
│   └── samples_data.py      # Curated test gallery with multi-reference ground-truth captions
├── frontend/
│   ├── index.html           # Modern Single-Page Application (Tailwind CSS, Glassmorphism)
│   └── static/
│       ├── css/
│       │   └── style.css    # Custom styles, responsive layout, animations
│       └── js/
│           └── app.js       # UI controller, webcam capture, TTS, API integration
├── data/                    # Dataset directory for training (e.g. Flickr8k)
├── models/                  # Checkpoint storage (.pth files)
├── train.py                 # End-to-end PyTorch training pipeline with Flickr8k loader
├── evaluate.py              # CLI benchmark script computing corpus BLEU metrics
├── requirements.txt         # Python package specifications
├── start.py                 # Universal 1-click launcher (auto port detection & browser launch)
├── run.bat                  # Windows batch launcher
└── README.md                # Comprehensive documentation
```

---

## 🚀 Quick Start Guide

### 1. Launch the Web Application
You can run the web application immediately! Simply execute:

```bash
# Using the project's virtual environment
.venv\Scripts\python.exe start.py
```
Or on Windows, double-click **`run.bat`**.

The server will automatically start at **`http://127.0.0.1:8000`** and open your default browser.

### 2. Install PyTorch & Full Training Packages (Optional / For Training)
If you wish to train the model from scratch on custom datasets:
```bash
pip install -r requirements.txt
```

---

## 📊 Training on Flickr8k Dataset

1. Download the [Flickr8k Dataset](https://www.kaggle.com/datasets/adityajn105/flickr8k) (Images and `captions.txt`).
2. Place the dataset files into `data/flickr8k/`:
   ```
   data/flickr8k/
   ├── captions.txt
   └── Images/
       ├── 1000268201_693b08cb0e.jpg
       └── ...
   ```
3. Run the training script:
   ```bash
   python train.py --epochs 15 --batch_size 32 --lr 0.0003
   ```
   Checkpoints and loss curves will be automatically saved to `models/`.

4. Run the benchmark evaluation:
   ```bash
   python evaluate.py
   ```

---

## 📐 Mathematical Formulation

### 1. LSTM Cell Formulation
At time step $t$, given input token embedding $x_t$, previous hidden state $h_{t-1}$, and previous cell memory $c_{t-1}$:
$$i_t = \sigma(W_{ii} x_t + b_{ii} + W_{hi} h_{t-1} + b_{hi})$$
$$f_t = \sigma(W_{if} x_t + b_{if} + W_{hf} h_{t-1} + b_{hf})$$
$$g_t = \tanh(W_{ig} x_t + b_{ig} + W_{hg} h_{t-1} + b_{hg})$$
$$o_t = \sigma(W_{io} x_t + b_{io} + W_{ho} h_{t-1} + b_{ho})$$
$$c_t = f_t \odot c_{t-1} + i_t \odot g_t$$
$$h_t = o_t \odot \tanh(c_t)$$

### 2. BLEU Score Formulation
$$\text{BLEU} = \text{BP} \cdot \exp\left( \sum_{n=1}^N w_n \ln p_n \right)$$
$$\text{BP} = \begin{cases} 1 & \text{if } c > r \\ e^{1 - r/c} & \text{if } c \le r \end{cases}$$
where $c$ is candidate length, $r$ is reference length, and $p_n$ is modified $n$-gram precision.

---

## 🎓 Academic Defense & Presentation Tips

- **Why CNN + LSTM?**
  CNN excels at spatial feature representation from 2D pixel grids; LSTM excels at sequential modeling and preserving temporal context over variable-length sentences.
- **Why Beam Search over Greedy Decoding?**
  Greedy search picks the locally optimal word at step $t$, which can lead to suboptimal sentences overall. Beam search tracks $K$ high-probability candidate trajectories simultaneously.
- **Why BLEU-4 as standard metric?**
  BLEU-4 measures 4-gram precision, ensuring both lexical accuracy and natural syntactic fluency.
