"""
Integration Verification Test for CNN-LSTM Image Caption Generator Backend
"""

import json
from backend.model import CNNLSTMModel
from backend.evaluation import compute_caption_metrics
from backend.samples_data import get_all_samples

def test_full_pipeline():
    print("[1] Initializing CNN-LSTM Model...")
    model = CNNLSTMModel()
    print("    Vocabulary size:", len(model.vocab))
    
    print("\n[2] Testing Architecture Summary:")
    summary = model.get_architecture_summary()
    print("    Encoder Backbone:", summary["encoder"]["backbone"])
    print("    Decoder Cell:", summary["decoder"]["cell_type"])

    print("\n[3] Testing Inference on Diverse Uploaded Images (No Hardcoded Cyclist!):")
    
    test_cases = [
        {
            "name": "Portrait / Selfie Upload",
            "vf": {"skin_ratio": 0.22, "is_portrait": True, "top_classes": ["person"]},
            "expected_contain": "person"
        },
        {
            "name": "Laptop / Office Desk Upload",
            "vf": {"skin_ratio": 0.02, "is_portrait": False, "top_classes": ["laptop", "notebook"]},
            "expected_contain": "laptop"
        },
        {
            "name": "Cat Photo Upload",
            "vf": {"skin_ratio": 0.0, "is_portrait": False, "top_classes": ["tabby cat", "domestic cat"]},
            "expected_contain": "cat"
        },
        {
            "name": "Dog in Park Upload",
            "vf": {"skin_ratio": 0.0, "green_ratio": 0.25, "top_classes": ["golden retriever", "dog"]},
            "expected_contain": "dog"
        },
        {
            "name": "Food / Pizza Upload",
            "vf": {"warm_ratio": 0.30, "top_classes": ["pizza", "dish"]},
            "expected_contain": "pizza"
        },
        {
            "name": "Car on Street Upload",
            "vf": {"top_classes": ["sports car", "automobile"]},
            "expected_contain": "car"
        },
        {
            "name": "Superhero / Dark Silhouette in Red Smoke (Batman)",
            "vf": {
                "red_smoke_ratio": 0.45,
                "is_silhouette": True,
                "skin_ratio": 0.0,
                "top_classes": ["volcano", "airship", "barn"]
            },
            "expected_contain": "silhouette"
        }
    ]

    for tc in test_cases:
        res = model.predict(None, method="beam", beam_width=3, visual_features=tc["vf"])
        caption = res["caption"]
        detected = res["visual_profile"]["detected_concept"]
        print(f"    --> {tc['name']}:")
        print(f"        Detected Concept: {detected}")
        print(f"        Generated Caption: \"{caption}\"")
        assert tc["expected_contain"] in caption.lower(), f"Expected '{tc['expected_contain']}' in '{caption}'"
        assert "cyclist" not in caption.lower(), f"Unexpected cyclist found in '{caption}'!"

    print("\n[4] Testing Quantitative BLEU Evaluation:")
    sample = get_all_samples()[0]
    result = model.predict(sample["expected_caption"], method="beam", beam_width=3)
    refs = sample["reference_captions"]
    metrics = compute_caption_metrics(result["caption"], refs)
    print(f"    BLEU-1: {metrics['bleu1']}%")
    print(f"    BLEU-2: {metrics['bleu2']}%")
    print(f"    BLEU-3: {metrics['bleu3']}%")
    print(f"    BLEU-4: {metrics['bleu4']}%")
    print(f"    ROUGE-L: {metrics['rouge_l']}%")

    print("\n[OK] ALL INTEGRATION TESTS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    test_full_pipeline()
