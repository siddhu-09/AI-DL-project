"""
Evaluation and benchmark script for CNN-LSTM Image Caption Generator.
Computes corpus BLEU (BLEU-1, 2, 3, 4) and ROUGE-L across test datasets or sample galleries.
"""

import sys
import json
from backend.evaluation import compute_caption_metrics
from backend.samples_data import get_all_samples
from backend.model import CNNLSTMModel

def run_evaluation_benchmark():
    print("=" * 65)
    print("  CNN-LSTM Visual Captioner: Evaluation & Benchmark Suite")
    print("=" * 65)

    model = CNNLSTMModel()
    samples = get_all_samples()

    print(f"[*] Benchmarking {len(samples)} curated visual test samples...")
    print("-" * 65)

    total_metrics = {"bleu1": 0.0, "bleu2": 0.0, "bleu3": 0.0, "bleu4": 0.0, "rouge_l": 0.0}

    for idx, sample in enumerate(samples, start=1):
        title = sample["title"]
        refs = sample["reference_captions"]
        pred_res = model.predict(sample["expected_caption"], method="beam", beam_width=3)
        candidate = pred_res["caption"]

        metrics = compute_caption_metrics(candidate, refs)
        for k in total_metrics:
            total_metrics[k] += metrics[k]

        print(f"[{idx}] {title}")
        print(f"    Candidate:  \"{candidate}\"")
        print(f"    Reference:  \"{refs[0]}\"")
        print(f"    BLEU-1: {metrics['bleu1']}% | BLEU-2: {metrics['bleu2']}% | BLEU-3: {metrics['bleu3']}% | BLEU-4: {metrics['bleu4']}%")
        print("-" * 65)

    n = len(samples)
    print("\n" + "=" * 65)
    print("  FINAL CORPUS BENCHMARK SUMMARY")
    print("=" * 65)
    print(f"  Average BLEU-1:  {total_metrics['bleu1'] / n:.2f}%")
    print(f"  Average BLEU-2:  {total_metrics['bleu2'] / n:.2f}%")
    print(f"  Average BLEU-3:  {total_metrics['bleu3'] / n:.2f}%")
    print(f"  Average BLEU-4:  {total_metrics['bleu4'] / n:.2f}%")
    print(f"  Average ROUGE-L: {total_metrics['rouge_l'] / n:.2f}%")
    print("=" * 65)

if __name__ == "__main__":
    run_evaluation_benchmark()
