"""
Universal Launcher for the CNN-LSTM Image Caption Generator Web Application.
Automatically detects port availability, starts the backend server, and opens the web application in your default browser.
"""

import os
import sys
import socket
import webbrowser
import threading
import time

def find_available_port(start_port: int = 8000, max_attempts: int = 20) -> int:
    """Finds an open TCP port starting from start_port."""
    for port in range(start_port, start_port + max_attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    return start_port

def open_browser_delayed(url: str, delay: float = 1.0):
    """Opens browser after server has started."""
    time.sleep(delay)
    try:
        webbrowser.open(url)
    except Exception:
        pass

def main():
    port = find_available_port(8080)
    url = f"http://127.0.0.1:{port}"

    print("=" * 70)
    print("   NEUROCAPTION: CNN-LSTM IMAGE CAPTION GENERATOR")
    print("   Deep Learning Project with ResNet-50 & Recurrent LSTM")
    print("=" * 70)
    print(f"[*] Starting local web server at: {url}")
    print(f"[*] Opening browser automatically...")
    print("=" * 70)

    # Launch browser in separate background thread
    threading.Thread(target=open_browser_delayed, args=(url,), daemon=True).start()

    # Import and run server
    from backend.app import run_server
    run_server(port=port, host="127.0.0.1")

if __name__ == "__main__":
    main()
